let config = {
  map: {
    '*': {
      OpenPix: 'https://plugin.openpix.com.br/v1/openpix.js',
    },
  },
};
