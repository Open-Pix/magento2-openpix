// @woovi/do-not-merge

let config = {
  map: {
    '*': {
      OpenPix: 'http://localhost:4444/openpix.js',
    },
  },
};
