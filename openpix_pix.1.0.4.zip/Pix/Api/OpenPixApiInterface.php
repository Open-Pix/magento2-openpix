<?php

namespace OpenPix\Pix\Api;

interface OpenPixApiInterface {
    /**
     * GET version of OpenPix magento2 webapi
     * @return string
     */
    public function getVersion();
}
